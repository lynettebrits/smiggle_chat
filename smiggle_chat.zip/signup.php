<?php

//phpinfo(32); //check what information has been passed to this page
//determine the user's browser, for necessary adjustments
//submitted login details
$username = $_POST["username"];
$email = $_POST["username"];
$pwd = $_POST["password"];

$conn = new mysqli("localhost", "violetfl_root", "admin", "violetfl_smiggle");

$sql = "INSERT INTO users (username,email,password) VALUES ('$username','$email','$pwd') ;";
$result = $conn->query($sql);
if ($result === false) {
    echo "<p>" . $conn->error . "</p>";
}

$sql = "SELECT userid FROM users WHERE email='$email' AND username='$email' AND password='$pwd';";
$result = $conn->query($sql);
        if ($result === false) {
            echo "<p>" . $conn->error . "</p>";
        }
        while ($row = $result->fetch_row()) {
            foreach ($row as $k => $userid) {
                $userid;
            }
        }

$sql = "INSERT INTO online (userid, login_time, logoff_time) VALUES ('$userid', now(), 0);";
    $result = $conn->query($sql);
    if ($result === false) {
        echo "<p>" . $conn->error . "</p>";
    }
    
    session_start();
    $_SESSION["userid"] = $userid;
    $_SESSION["username"] = $username;
    $_SESSION["email"] = $email;
    $_SESSION["password"] = $password;

    $sql = "INSERT INTO online (userid, login_time, logoff_time) VALUES ('{$_SESSION['userid']}', now(), 0);";
    echo $sql;
    $result = $conn->query($sql);
    if ($result === false) {
        echo "<p>" . $conn->error . "</p>";
    }
    $conn->close(); //close conection
    header("location:chatlist.php");

?>	