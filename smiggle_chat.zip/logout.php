<?php
	/*
	* This code logs a user out of the back-end, by destroying the session variable.
	* Redirects the user to the login page.
	*/
	
	//initialise session
	session_start(); 
        $conn = new mysqli("localhost", "violetfl_root", "admin", "violetfl_smiggle");
        $sql = "UPDATE online SET logoff_time=now() WHERE userid={$_SESSION["userid"]};";
        $result = $conn->query($sql);
        if ($result === false) {
            echo "<p>" . $conn->error . "</p>";
        }
	
	//unset all of the session variables
	$_SESSION = array(); 
	
	//destroy the session
	session_destroy();
	
	//redirect
	header("location:index.php"); //2 : "You have logged out successfully..." 
?>