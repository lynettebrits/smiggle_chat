<?php


//phpinfo(32); //check what information has been passed to this page
//determine the user's browser, for necessary adjustments
//submitted login details
$eml = $_GET["username"];
$pwd = $_GET["password"];

$conn = new mysqli("localhost", "violetfl_root", "admin", "violetfl_smiggle");

$sql = "SELECT * FROM users WHERE email='$eml' AND password='$pwd' ;";
$result = $conn->query($sql);
$numrows = $result->num_rows;
if ($numrows == 1) { //match; correct login - set session variables and redirect to the back-end menu page
    session_start();
    $row = $result->fetch_array();
    $_SESSION["userid"] = $row[0];
    $_SESSION["username"] = $row[1];
    $_SESSION["email"] = $row[2];
    $_SESSION["password"] = $row[3];
    
    $sql = "INSERT INTO online (userid, login_time, logoff_time) VALUES ('{$_SESSION['userid']}', now(), 0);";
    $result = $conn->query($sql);
    if ($result === false) {
        echo "<p>" . $conn->error . "</p>";
    }
$conn->close(); //close conection
    header("location:chatlist.php");
} else { //incorrect login - redirect to login page
    $conn->close(); //close connection
    header("location:index.php?message=1"); //1 : "Invalid login - please try again..."
}
?>	