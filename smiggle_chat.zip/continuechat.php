<?php
session_start();
$strhtml = '<!doctype html>'
?>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="../../favicon.ico">

        <title>Dashboard Template for Bootstrap</title>

        <!-- Bootstrap core CSS -->
        <link href="dist/css/bootstrap.min.css" rel="stylesheet">

        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/styles.css" rel="stylesheet">

        <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
        <!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
        <script src="assets/js/ie-emulation-modes-warning.js"></script>

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>

    <body>
        <?php
        include_once 'form_functions.php';
        $conn = new mysqli("localhost", "violetfl_root", "admin", "violetfl_smiggle");
        
            ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-3 col-md-2 sidebar">
                        <?php
                        $sql = "SELECT users.userid as userid, users.username AS username, users.email AS email FROM users INNER JOIN online ON users.userid=online.userid WHERE online.login_time<now() AND online.logoff_time=0 AND users.userid!={$_SESSION['userid']} AND users.userid!={$_GET["friend"]} ORDER BY username;";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            echo "<ul class='nav nav-sidebar'>";
                            echo "<h2>Start a new Chat</h2>";
                            // output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "<li>" . "<a href='newchat.php?friend=" . $row["userid"] . "'>" . $row["username"] . "</a>" . "</li>";
                            }
                            echo "</ul>";
                        } else {
                            echo "No Friends Online";
                        }
                        $sql = "SELECT users.userid as userid, users.username AS username, users.email AS email FROM users INNER JOIN online ON users.userid=online.userid WHERE online.login_time<now() AND online.logoff_time=0 AND users.userid!={$_SESSION['userid']} ORDER BY username;";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            echo "<ul class='nav nav-sidebar'>";
                            echo "<h2>Continue a Chat</h2>";
                            // output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "<li>" . "<a href='continuechat.php?friend=" . $row["userid"] . "'>" . $row["username"] . "</li>";
                            }
                            echo "</ul>";
                        } else {
                            echo "No Friends Online";
                        }
                        ?>
                        </ul>
                        <div class="logout">
                            <p><a href="logout.php">Logout</a>
                        </div>
                    </div>
                    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 chat">
                        <h1>Smiggle Chat</h1>
                        <h2 class="sub-header">Lets Chat</h2>
                        <div class="chat_body">
                            <?php
                            $sql = "SELECT chat.userid, chat.time as time, chat.message as message, users.username as username FROM chat INNER JOIN users on users.userid=chat.userid WHERE (chat.userid={$_SESSION['userid']} AND chat.recipientid={$_GET['friend']}) OR (chat.userid={$_GET['friend']} AND chat.recipientid={$_SESSION['userid']}) ;";

                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {

                                // output data of each row
                                while ($row = $result->fetch_assoc()) {
                                    echo "<div class='chatbody'>" . "<div class='time'>" . $row["time"] . "</div>" . "<div class='username'>" . $row['username'] . "</div>" . "<div class='message'>" . $row["message"] . "</div>" . "</div>";
                                }
                            } else {
                                echo "Start Chat";
                            }
                            ?>
                        </div>
                        <div class="space">&nbsp;</div>
                        <div class="chat_input">
                            <form class="" name="sendchat" action="newchat_send.php" method="post">
                                <?php
                                $friend = $_GET['friend'];
                                echo formLabel("", "chatinput") . textAreaRequired("chatinput", "", "chatinput") . hidden("friend", $friend) . submit("chatsubmit", ">>");
                                ?>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="dist/js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
