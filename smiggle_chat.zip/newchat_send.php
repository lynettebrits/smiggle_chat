<?php

session_start();
$conn = new mysqli("localhost", "violetfl_root", "admin", "violetfl_smiggle");
$friend = $_POST['friend'];
$sql = "INSERT INTO chat (userid, recipientid, time, message) VALUES ('{$_SESSION['userid']}', '$friend', now(), '{$_POST['chatinput']}');";
$result = $conn->query($sql);
if ($result === false) {
    echo "<p>" . $conn->error . "</p>";
}
unset($_POST['chatinput']);
header("location:newchat.php?friend=$friend");
?>	